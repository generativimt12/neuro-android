# NEURO — Android project (local, no server)

This is a complete, ready-to-build Android Studio project. The whole app —
UI, the binaural-beat audio engine, the visualizer, the Frequency Lab, and
the Hebrew/English toggle — runs **entirely on-device**, inside a single
offline HTML/JS file (`app/src/main/assets/neuro.html`) loaded into a native
WebView wrapper (`MainActivity.kt`).

There is no backend, no analytics SDK, no ads SDK, and the manifest
deliberately requests **no `INTERNET` permission** — the app cannot make a
network call even if it wanted to. Session history and lab presets are
stored with the device's local `localStorage`, private to the app.

## What you need on your machine

- **Android Studio** (Koala/2024.1 or newer) — free, from
  https://developer.android.com/studio
- That's it. Android Studio bundles the JDK and will download the Android
  SDK and the exact Gradle version this project needs the first time you
  open it (needs internet **once**, on your machine, not here).

## Build the APK

1. Unzip this project.
2. Open Android Studio → **Open** → select the unzipped `neuro-android`
   folder.
3. Let it sync (first time: Android Studio will offer to download the
   missing Gradle wrapper / SDK components — accept).
4. **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. When it finishes, click the **locate** link in the notification, or find
   the file at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copy that `.apk` to your phone (or drag it onto an emulator window) and
   install it. You may need to allow "install from unknown sources" once.

### Command line instead of the IDE

```bash
cd neuro-android
./gradlew assembleDebug
```
(If `./gradlew` complains the wrapper jar is missing, run `gradle wrapper`
once with any locally installed Gradle, or just open the project in Android
Studio first — it fixes this automatically.)

The output is a **debug APK**, fine for installing on your own phone. If you
ever want to publish it to the Play Store, you'll additionally need to
generate a signing key and build a **release** APK/AAB — Android Studio's
Build menu has a wizard for that (Build → Generate Signed Bundle / APK).

## Project layout

```
neuro-android/
├── app/
│   ├── build.gradle.kts          # app module config (min/target SDK, deps)
│   └── src/main/
│       ├── AndroidManifest.xml   # no INTERNET permission
│       ├── java/com/neuro/app/
│       │   └── MainActivity.kt   # WebView wrapper, loads the local app
│       ├── assets/
│       │   └── neuro.html        # the entire app: UI + audio engine + i18n
│       └── res/                  # app name, theme, launcher icon
├── build.gradle.kts              # root project config
└── settings.gradle.kts
```

## Editing the app itself

Everything a designer/developer would touch day to day — screens, colors,
copy, the Hebrew/English strings, the state profiles, the audio engine — is
in the one file `app/src/main/assets/neuro.html`. Edit it, rebuild, done; no
need to touch the Kotlin wrapper at all.

## Honest limitations of this version

This is a **client-only** build matching what's in the PRD's "MODE A /
MODE B" experience, the Session Engine timeline (simplified to entry / deep
/ exit phases), the real-time binaural engine (two independent oscillators
merged into left/right channels, with ramp), four ambient background types,
and the Frequency Lab. It does **not** yet include: accounts/cloud sync,
push notifications, in-app purchase/subscription billing, or analytics —
all of which the PRD scopes as backend-dependent work for a development
team, not something that belongs in an offline local build.
